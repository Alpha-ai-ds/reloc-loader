#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
so_loader —— 在用户态「加载」一个 stripped AArch64 ELF 并应用重定位，
            得到一个可读的**加载后内存视图**。

==============================================================================
它解决什么问题
==============================================================================

对 stripped 的 ARM64 共享库做静态分析时，你迟早会撞上这堵墙：

    >>> 想读某个类的 vtable
    >>> 找到 vtable 地址 0x1270fa98
    >>> read(0x1270fa98, 8)
    b'\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00'      ← 全是 0
    >>> read(0x1270fa98 + 8, 8)
    b'\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00'      ← 还是 0

原因不是你算错了地址，而是：**虚表槽位在文件里本来就是 0**。

C++ 的 vtable 放在 `.data.rel.ro` 段，每个槽位是一个指向代码段的绝对地址。
编译时不知道运行基址，所以链接器把它写为 0，同时在 `.rela.dyn` 里留一条
`R_AARCH64_RELATIVE`，让动态链接器在加载时填入 `base + addend`。

于是一个残酷的事实成立了：

    不重定位，就读不到任何 vtable；
    读不到 vtable，就分不清类、追不了虚调用、扫不了类布局。

而动态链接器只存在于运行的进程里。做静态分析的人没有进程。

**本模块就是把动态链接器的这一步重做一遍** —— 纯数据操作，不需要真的
mmap、不需要执行代码、不需要 root。读完 .rela.dyn，把几十万条
R_*_RELATIVE 打进补丁表，之后所有 read() 都是「加载后」的语义。

实测（318MB 的 libminecraftpe.so）：

    重定位: 967,158 项
      R_AARCH64_RELATIVE : 774,934     ← 全部应用
    补丁表: 774,934 项
    Player vtable @0x1270fa98  → 273 槽   ✓（重定位前全 0）
    Level  vtable @0x127275c8  → 517 槽   ✓

==============================================================================
用法
==============================================================================

    rt = SoRuntime('libfoo.so')

    rt.read_ptr(0x1270fa98)          # 读加载后的 8 字节指针
    rt.read(0x1270fa98, 0x100)       # 读一块内存（补丁优先，其次文件，bss 补零）
    rt.vtable_entries(0x1270fa98)    # 读整张虚表，返回到第一个无效槽为止
    rt.vtable_len(0x1270fa98)        # 虚表槽位数（常用于估算「这是哪个类」）
    rt.dump_region(va, size)         # 导出一块内存，可直接喂给 Unicorn
    rt.in_exec(0x747559c)            # 某地址是否落在可执行段

==============================================================================
设计取舍
==============================================================================

1. **不把整个文件读进内存。** 318MB 的文件，靠 seek + 分块读。
   重定位表本身用 numpy 分块解析（4MB 一块），避免一次性 22MB 进内存。

2. **补丁表而不是复制整个镜像。** 只有 774,934 个 8 字节槽位真正被改写，
   存成 dict 即可；其余字节一律回退到文件读。内存占用与文件大小无关。

3. **不模拟执行。** 那是 Unicorn 的活。这里只做「让内存变得可读」这一件事。
   分工明确：本模块产出数据，Unicorn 消费数据。

4. **不处理 IRELATIVE。** R_AARCH64_IRELATIVE 需要真的执行 resolver 函数，
   纯静态无法确定结果。这类条目会被统计但跳过（不静默丢弃）。

==============================================================================
已知限制
==============================================================================

* 只处理 AArch64（e_machine == 183）。其他架构的重定位语义不同。
* 需要 `.rela.dyn` 存在。若 so 被特殊处理过（如自定义加载器），可能不适用。
* 只应用 RELATIVE 类重定位（重基址）。符号类重定位（GLOB_DAT /
  JUMP_SLOT / ABS64）涉及外部符号解析，不在本模块范围内 —— 但对于
  「读 vtable」这个目标，RELATIVE 就是全部所需。
* 节名不可信时按 type 定位（见下）。
"""

import struct
import numpy as np

# ------------------------------------------------------------------ 常量
R_AARCH64_ABS64 = 257
R_AARCH64_GLOB_DAT = 1025
R_AARCH64_JUMP_SLOT = 1026
R_AARCH64_RELATIVE = 1027
R_AARCH64_IRELATIVE = 1032

SHT_RELA = 4
SHT_REL = 9
PT_LOAD = 1
PF_X = 1

EM_AARCH64 = 183
EM_X86_64 = 62

# 重定位类型名：按 (machine, type) 查。
# 只列 RELATIVE 家族和常见的几个 —— 重点是把 RELATIVE 认准，
# 其余的只做统计归类，不需要精确语义。
RELOC_NAMES = {
    EM_AARCH64: {
        257: 'R_AARCH64_ABS64',
        1024: 'R_AARCH64_COPY',
        1025: 'R_AARCH64_GLOB_DAT',
        1026: 'R_AARCH64_JUMP_SLOT',
        1027: 'R_AARCH64_RELATIVE',
        1032: 'R_AARCH64_IRELATIVE',
    },
    EM_X86_64: {
        1: 'R_X86_64_64',
        6: 'R_X86_64_GLOB_DAT',
        7: 'R_X86_64_JUMP_SLOT',
        8: 'R_X86_64_RELATIVE',
        37: 'R_X86_64_IRELATIVE',
    },
}

# 每个架构的「重基址」重定位类型 —— 本工具实际应用的只有这些
RELOC_RELATIVE = {
    EM_AARCH64: 1027,      # R_AARCH64_RELATIVE
    EM_X86_64: 8,          # R_X86_64_RELATIVE
}

# IRELATIVE：需要真的执行 resolver 才能知道结果，静态无法确定
RELOC_IRELATIVE = {
    EM_AARCH64: 1032,
    EM_X86_64: 37,
}

# REL 与 RELA 的条目宽度（REL 没有 addend，靠隐式加数）
RELOC_ENTSIZE = {SHT_RELA: 24, SHT_REL: 16}

MACHINE_NAMES = {EM_AARCH64: 'AArch64', EM_X86_64: 'x86-64'}


class SoRuntimeError(Exception):
    pass


class SoRuntime:
    """一个 ELF 的「加载后视图」。

    :param path: .so 文件路径
    :param base: 设想的加载基址。默认 0（即 ELF 自带的 vaddr 就是最终地址）。
                 若知道真实的 ASLR 基址，传入后所有指针会相应地偏移。
    """

    def __init__(self, path, base=0):
        self.path = path
        self.base = base
        self.f = open(path, 'rb')
        self._parse_elf()
        self._apply_relocations()

    # ================================================================ ELF
    def _parse_elf(self):
        f = self.f
        f.seek(0)
        if f.read(4) != b'\x7fELF':
            raise SoRuntimeError('%s: not an ELF' % self.path)

        f.seek(0x10)
        self.e_type, self.e_machine = struct.unpack('<HH', f.read(4))
        if self.e_machine not in (EM_AARCH64, EM_X86_64):
            raise SoRuntimeError(
                'e_machine=%d (%s) not supported; need %s'
                % (self.e_machine,
                   MACHINE_NAMES.get(self.e_machine, 'unknown'),
                   ' / '.join('%s=%d' % (v, k) for k, v in MACHINE_NAMES.items())))
        self.machine = self.e_machine
        self.reloc_relative = RELOC_RELATIVE[self.e_machine]
        self.reloc_irelative = RELOC_IRELATIVE.get(self.e_machine, -1)

        f.seek(0x20)
        self.phoff = struct.unpack('<Q', f.read(8))[0]
        f.seek(0x28)
        self.shoff = struct.unpack('<Q', f.read(8))[0]

        # 注意：e_phentsize/e_phnum 在 0x36，
        #       e_shentsize/e_shnum/e_shstrndx 在 0x3A。
        #       不要从 0x3A 连着读 5 个 H —— 那是错的。
        f.seek(0x36)
        self.phentsize, self.phnum = struct.unpack('<HH', f.read(4))
        f.seek(0x3A)
        self.shentsize, self.shnum, self.shstrndx = struct.unpack('<HHH', f.read(6))

        self._parse_phdrs()
        self._parse_shdrs()

    def _parse_phdrs(self):
        f = self.f
        f.seek(self.phoff)
        ph = f.read(self.phentsize * self.phnum)
        self.segs = []
        for i in range(self.phnum):
            o = i * self.phentsize
            p_type, p_flags = struct.unpack_from('<II', ph, o)
            p_off, p_vaddr, _p_paddr, p_filesz, p_memsz = struct.unpack_from(
                '<QQQQQ', ph, o + 8)
            if p_type == PT_LOAD:
                self.segs.append(dict(off=p_off, va=p_vaddr + self.base,
                                      fsz=p_filesz, msz=p_memsz, flags=p_flags))
        if not self.segs:
            raise SoRuntimeError('no PT_LOAD segments')
        # 段地址统一带上 base —— 这样 in_exec / read / v2o 全都在
        # 同一个坐标系里工作。曾经漏掉这一步，导致 base != 0 时
        # in_exec 把重定位后的指针全判成「不在代码段」。
        self.exec_ranges = [(s['va'], s['va'] + s['fsz'])
                            for s in self.segs if s['flags'] & PF_X]
        self.data_ranges = [(s['va'], s['va'] + s['msz'])
                            for s in self.segs if not (s['flags'] & PF_X)]

    def _parse_shdrs(self):
        """解析节头。

        坑：某些 so 的 .shstrtab 被混淆成非 ASCII，节名读出来是乱码。
        所以**不要依赖节名**定位关键节 —— 一律用 sh_type。
        本模块只在报告里尝试解析节名，且失败也不会中断。
        """
        f = self.f
        f.seek(self.shoff)
        sh = f.read(self.shentsize * self.shnum)
        self.sections = []
        for i in range(self.shnum):
            o = i * self.shentsize
            sh_name, sh_type = struct.unpack_from('<II', sh, o)
            sh_flags, sh_addr, sh_off, sh_size = struct.unpack_from('<QQQQ', sh, o + 8)
            self.sections.append(dict(idx=i, name_off=sh_name, type=sh_type,
                                      flags=sh_flags, addr=sh_addr,
                                      off=sh_off, size=sh_size))
        # 尽力解析节名（失败就留空）
        self._try_name_sections(sh)
        self.sec = {}
        for s in self.sections:
            if s.get('name'):
                self.sec[s['name']] = s

    def _try_name_sections(self, sh):
        if self.shstrndx >= self.shnum:
            return
        o = self.shstrndx * self.shentsize
        _f, _a, stroff, strsz = struct.unpack_from('<QQQQ', sh, o + 8)
        try:
            self.f.seek(stroff)
            blob = self.f.read(strsz)
        except Exception:
            return
        for s in self.sections:
            p = s['name_off']
            if p >= len(blob):
                s['name'] = ''
                continue
            end = blob.find(b'\x00', p)
            if end < 0:
                end = len(blob)
            nm = blob[p:end]
            try:
                s['name'] = nm.decode('ascii')
            except UnicodeDecodeError:
                s['name'] = ''          # 被混淆了，认不出来就别硬认

    # ============================================================ 重定位
    def _apply_relocations(self):
        """按 sh_type 定位重定位表（RELA=4 / REL=9），应用 RELATIVE。

        为何同时支持 REL：32 位 ELF 和一些工具链产出的表是 REL
        （没有显式 addend，加数隐式存放在目标位置里）。
        对 RELATIVE 而言这意味着 addend 需要先从目标地址读出来。

        为何按 type 而不是节名定位：某些 so 的 .shstrtab 被混淆成非 ASCII，
        节名读出来是乱码，但 sh_type 永远是准确的。
        """
        self.patches = {}
        self.stats = {'total': 0, 'relative': 0, 'irelative': 0, 'other': {}}
        self.rela_sections = []

        for sec in self.sections:
            if sec['type'] not in (SHT_RELA, SHT_REL):
                continue
            esz = RELOC_ENTSIZE[sec['type']]
            is_rela = (sec['type'] == SHT_RELA)
            self.rela_sections.append(sec)
            n = sec['size'] // esz
            if n == 0:
                continue
            CH = 1 << 22                     # 每块 ~175k 项（RELA 时约 4MB）
            done = 0
            while done < n:
                cnt = min(CH, n - done)
                raw = self._fread(sec['off'] + done * esz, cnt * esz)
                if is_rela:
                    arr = np.frombuffer(raw, dtype=np.uint64).reshape(-1, 3)
                    offs = arr[:, 0]
                    adds = arr[:, 2].astype(np.int64)
                else:
                    arr = np.frombuffer(raw, dtype=np.uint64).reshape(-1, 2)
                    offs = arr[:, 0]
                    adds = None
                infos = arr[:, 1]
                typ = (infos & 0xFFFFFFFF).astype(np.uint64)

                for t in np.unique(typ):
                    m = (typ == t)
                    c = int(m.sum())
                    self.stats['total'] += c
                    t = int(t)
                    if t == self.reloc_relative:
                        self.stats['relative'] += c
                        tgt = offs[m]
                        if is_rela:
                            a_ = adds[m]
                        else:
                            # REL：加数隐式存放在目标地址处
                            a_ = np.array([int.from_bytes(self.read(int(o), 8),
                                                          'little', signed=True)
                                           for o in tgt.tolist()], dtype=np.int64)
                        val = (self.base + a_).astype(np.uint64)
                        # tgt 是 ELF 里的原始 vaddr；patches 以「加载后 va」为键，
                        # 所以要加上 base，跟 segs['va'] 保持同一坐标系。
                        for a, v in zip(tgt.tolist(), val.tolist()):
                            self.patches[a + self.base] = v
                    elif t == self.reloc_irelative:
                        self.stats['irelative'] += c
                    else:
                        self.stats['other'][t] = self.stats['other'].get(t, 0) + c
                done += cnt

    # =============================================================== 读取
    def _fread(self, off, size):
        self.f.seek(off)
        return self.f.read(size)

    def v2o(self, va):
        """虚拟地址 → 文件偏移。不在任何 PT_LOAD 的 fsz 内则返回 None。"""
        for s in self.segs:
            if s['va'] <= va < s['va'] + s['fsz']:
                # s['va'] 已含 base，off 不含，这里要换算回原始 vaddr
                return s['off'] + (va - s['va'])
        return None

    def read(self, va, size):
        """加载后视图读取。

        优先级：补丁表 → 文件字节 → 补零（.bss / msz 超出 fsz 的部分）。
        """
        out = bytearray()
        pos = va
        while len(out) < size:
            if pos in self.patches:
                out += struct.pack('<Q', self.patches[pos])
                pos += 8
                continue
            o = self.v2o(pos)
            if o is None:
                # 落在 .bss（NOBITS）或段间空洞 —— 加载时为 0
                out += b'\x00'
                pos += 1
                continue
            chunk = min(size - len(out), 4096)
            self.f.seek(o)
            out += self.f.read(chunk)
            pos += chunk
        return bytes(out[:size])

    def read_ptr(self, va):
        return struct.unpack('<Q', self.read(va, 8))[0]

    def read_u32(self, va):
        return struct.unpack('<I', self.read(va, 4))[0]

    def in_exec(self, va):
        return any(a <= va < b for a, b in self.exec_ranges)

    def in_data(self, va):
        return any(a <= va < b for a, b in self.data_ranges)

    # =============================================================== 虚表
    def vtable_entries(self, vt_addr, maxn=600):
        """读虚表，到第一个无效槽为止。

        「有效」的判据：非 0、4 字节对齐、落在可执行段。
        这三个条件合起来能滤掉绝大多数噪声。
        """
        out = []
        for i in range(maxn):
            p = self.read_ptr(vt_addr + i * 8)
            if p == 0 or (p & 3) or not self.in_exec(p):
                break
            out.append(p)
        return out

    def vtable_len(self, vt_addr, maxn=3000):
        return len(self.vtable_entries(vt_addr, maxn))

    def dump_region(self, va, size):
        """导出一块加载后的内存，供 Unicorn 的 mem_write 直接使用。"""
        return self.read(va, size)

    # ==================================================== 批量扫描支持
    def _sorted_patch_arrays(self):
        """把补丁表整理成两个有序 numpy 数组，供向量化叠加使用。

        只算一次并缓存 —— 774k 条补丁排序大约几十毫秒，但扫描时可能要
        叠加上百次，不缓存会明显拖慢。
        """
        if getattr(self, '_pa', None) is None:
            if not self.patches:
                self._pa = (np.empty(0, dtype=np.uint64),
                            np.empty(0, dtype=np.uint64))
            else:
                ks = np.fromiter(self.patches.keys(), dtype=np.uint64,
                                 count=len(self.patches))
                vs = np.fromiter(self.patches.values(), dtype=np.uint64,
                                 count=len(self.patches))
                o = np.argsort(ks)
                self._pa = (ks[o], vs[o])
        return self._pa

    def read_ptr_array(self, va, count):
        """批量读指针，返回 numpy uint64 数组（已叠加重定位）。

        比循环调用 read_ptr 快两个数量级 —— 扫整个 .data.rel.ro 时
        这是能不能在可接受时间内跑完的关键。
        """
        size = count * 8
        raw = self._read_raw_fast(va, size)
        arr = np.frombuffer(raw, dtype=np.uint64).copy()
        ks, vs = self._sorted_patch_arrays()
        if ks.size:
            lo = np.searchsorted(ks, va, 'left')
            hi = np.searchsorted(ks, va + size, 'left')
            if hi > lo:
                # 只处理落在本窗口内的补丁
                sel_ks = ks[lo:hi]
                sel_vs = vs[lo:hi]
                idx = ((sel_ks - va) // 8).astype(np.int64)
                ok = (idx >= 0) & (idx < count) & ((sel_ks - va) % 8 == 0)
                arr[idx[ok]] = sel_vs[ok]
        return arr

    def _read_raw_fast(self, va, size):
        """不带补丁的原始读取，尽可能一次读一大块。"""
        out = bytearray()
        pos = va
        while len(out) < size:
            o = self.v2o(pos)
            if o is None:
                # 落在 .bss 或段间空洞 —— 补零
                # 为了速度，整段补到下一个段起点
                nxt = None
                for s in self.segs:
                    if s['va'] > pos:
                        nxt = min(nxt or s['va'], s['va'])
                fill = (nxt - pos) if nxt else (size - len(out))
                out += b'\x00' * min(fill, size - len(out))
                pos += min(fill, size - len(out))
                continue
            chunk = min(size - len(out), (1 << 22))
            self.f.seek(o)
            data = self.f.read(chunk)
            if not data:
                out += b'\x00' * (size - len(out))
                break
            out += data
            pos += len(data)
        return bytes(out[:size])

    def is_code_ptr(self, p):
        """一个指针是否「像」代码地址。

        三条判据：非 0、对齐、落在可执行段。
        注意第一条 —— 漏掉它会导致 0 被当成有效指针，
        扫出成千上万个假 vtable（本项目实测踩过）。
        """
        return bool(p) and (p & 3) == 0 and self.in_exec(p)

    # =============================================================== 报告
    def report(self):
        print('=' * 66)
        print('  %s  —— 加载后视图' % self.path.split('/')[-1])
        print('=' * 66)
        print('  PT_LOAD 段: %d' % len(self.segs))
        for s in self.segs:
            x = 'R+X' if (s['flags'] & PF_X) else 'RW '
            print('     %s va=0x%-10x off=0x%-10x fsz=0x%-9x msz=0x%-9x'
                  % (x, s['va'], s['off'], s['fsz'], s['msz']))
        names = RELOC_NAMES.get(self.machine, {})
        print('  架构: %s' % MACHINE_NAMES.get(self.machine, self.machine))
        print('\n  重定位: %d 项' % self.stats['total'])
        print('    %-22s: %d  ← 已应用 %d 条补丁'
              % (names.get(self.reloc_relative, 'RELATIVE'),
                 self.stats['relative'], len(self.patches)))
        if self.stats['irelative']:
            print('    %-22s: %d  ← 需执行 resolver，跳过'
                  % (names.get(self.reloc_irelative, 'IRELATIVE'),
                     self.stats['irelative']))
        for t, c in sorted(self.stats['other'].items(), key=lambda x: -x[1]):
            print('    %-22s: %d  ← 符号类，不在本模块范围'
                  % (names.get(t, 'type %d' % t), c))
        print('\n  重定位表:')
        for sec in self.rela_sections:
            kind = 'RELA' if sec['type'] == SHT_RELA else 'REL '
            print('     %s off=0x%-10x size=0x%-10x (%d 项)'
                  % (kind, sec['off'], sec['size'],
                     sec['size'] // RELOC_ENTSIZE[sec['type']]))
        named = [s for s in self.sections if s.get('name')]
        print('\n  节名解析: %d/%d 可读' % (len(named), len(self.sections)))
        if not named:
            print('     (.shstrtab 被混淆，已按 sh_type 定位，不影响功能)')
        print()


# ==================================================================== CLI
def _main():
    import sys
    if len(sys.argv) < 2:
        print(__doc__)
        print('用法: python3 so_loader.py <lib.so> [vtable_addr ...]')
        return
    path = sys.argv[1]
    rt = SoRuntime(path)
    rt.report()
    for arg in sys.argv[2:]:
        try:
            va = int(arg, 0)
        except ValueError:
            continue
        n = rt.vtable_len(va)
        print('  vtable @0x%x -> %d 槽' % (va, n))
        for i, p in enumerate(rt.vtable_entries(va, 8)):
            print('     [%d] 0x%x' % (i, p))
        print()


if __name__ == '__main__':
    _main()
