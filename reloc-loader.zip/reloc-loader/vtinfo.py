#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
vtinfo —— 在「加载后视图」之上做类结构分析。

so_loader 解决的是「读得到」，vtinfo 解决的是「读出来是什么」。

对于一个 stripped 的 C++ so，拿到一张 vtable 之后你通常想知道：

  1. 这个类有哪些成员字段？（找 `ldr x0,[x0,#imm]; ret` 这种 getter thunk，
     imm 直接就是字段偏移 —— 比扫实例内存可靠得多，因为类布局是编译期确定的）
  2. 里面有没有容器？（找 `ldp x_a,x_b,[xN,#imm]` + `lsr #k`，
     这是内联的 vector.size()，imm = 容器偏移，1<<k = 元素宽度）
  3. 它跟别的类是什么关系？（比较两个 vtable 的槽位指纹）

本模块就是这三件事。

为什么「扫类代码」优于「扫实例内存」
------------------------------------
扫实例内存需要活的进程：对象在堆上，地址每次运行都随机，静态文件里根本没有。
扫类代码不需要：类的成员方法就在 .text 里，编译期就确定了它访问哪些字段。

这不是妥协，其实是更好的锚点 —— 换版本时你也能用它来重新定位字段。

用法
----
    python3 vtinfo.py <lib.so> <vtable_addr> [--all]
"""

import re
import sys
from collections import Counter

try:
    from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN
except ImportError:
    sys.exit('需要 capstone:  pip install capstone')

from so_loader import SoRuntime


def _imm(operand):
    """从操作数里取立即数。

    坑：capstone 对 lsr 输出的是**十进制**（`lsr x8, x8, #3`），
    对 ldr 输出的是十六进制（`ldr x0, [x0, #0x340]`）。
    两种都要能吃下。
    """
    m = re.search(r'#(-?0x[0-9a-fA-F]+|-?\d+)', operand)
    if not m:
        return None
    s = m.group(1)
    if s.lower().startswith(('-0x', '0x')):
        return int(s.replace('-0x', '-0x'), 16)
    return int(s, 10)


def _base_reg(operand):
    m = re.search(r'\[(x\d+|sp|x29)', operand)
    return m.group(1) if m else None


class ClassInfo:
    def __init__(self, rt, vt_addr, maxslot=600, maxins=400):
        self.rt = rt
        self.vt = vt_addr
        self.md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
        self.md.detail = False
        self.slots = rt.vtable_entries(vt_addr, maxslot)
        self.maxins = maxins
        self.getters = []        # (slot, fn, offset)         ldr x0,[x0,#imm]; ret
        self.inline_getters = [] # (slot, fn, offset)         add x0,x0,#imm; ret
        self.containers = {}     # (offset, width) -> count
        self.container_samples = {}

    # ------------------------------------------------------------ 反汇编
    def _insns(self, va, n=None):
        n = n or self.maxins
        try:
            code = self.rt.read(va, n * 4)
        except Exception:
            return []
        out = []
        for ins in self.md.disasm(code, va):
            out.append((ins.address, ins.mnemonic, ins.op_str))
            if len(out) >= n:
                break
        return out

    # -------------------------------------------------------- 成员字段
    def scan_getters(self):
        """找 `ldr x0,[x0,#imm]; ret` —— 成员指针 getter。

        返回的对象指针偏移就是字段偏移，直接可读，不用猜。
        """
        for slot, fn in enumerate(self.slots):
            lst = self._insns(fn, 6)
            if len(lst) < 2:
                continue
            if lst[1][1] != 'ret':
                continue
            m, op = lst[0][1], lst[0][2]
            if not op.startswith('x0,'):
                continue
            i = _imm(op)
            if i is None or i == 0:
                continue
            if m == 'ldr' and '[x0' in op:
                self.getters.append((slot, fn, i))
            elif m == 'add' and op.startswith('x0, x0'):
                # add x0,x0,#imm; ret  —— 返回内联成员的地址
                self.inline_getters.append((slot, fn, i))
        return self

    # ---------------------------------------------------------- 容器
    def scan_containers(self):
        """找内联的 vector.size()：

            ldp  x_a, x_b, [xN, #imm]     ; begin / end
            sub  x,   x_b, x_a
            lsr  x,   x,   #k             ; 元素宽度 = 1 << k

        imm 是容器在对象内的偏移，1<<k 是元素宽度。

        注意用 ldp 而不是两条 ldr —— 编译器几乎总是用 ldp 一次取两个。
        """
        for slot, fn in enumerate(self.slots):
            lst = self._insns(fn)
            for i, (_a, m, op) in enumerate(lst):
                if m != 'ldp':
                    continue
                b = _base_reg(op)
                if b in ('sp', 'x29', None):
                    continue          # 栈上的不算对象字段
                i0 = _imm(op)
                if i0 is None:
                    continue
                for j in range(i + 1, min(i + 8, len(lst))):
                    m2, op2 = lst[j][1], lst[j][2]
                    if m2 == 'lsr':
                        k = _imm(op2)
                        if k is None or k < 2 or k > 6:
                            break
                        key = (i0, 1 << k)
                        self.containers[key] = self.containers.get(key, 0) + 1
                        self.container_samples.setdefault(key, (slot, fn))
                        break
                    if m2 in ('ret', 'bl', 'blr', 'br', 'b'):
                        break
        return self

    # ------------------------------------------------------------ 报告
    def report(self, label=''):
        print('=' * 66)
        print('  %s  vtable @0x%x' % (label or 'class', self.vt))
        print('=' * 66)
        print('  槽位数: %d' % len(self.slots))

        if self.getters:
            print('\n  成员指针 getter (%d 个，偏移可直接读):' % len(self.getters))
            for slot, fn, off in self.getters[:24]:
                print('     slot %-4d (0x%04x)  fn=0x%-9x  this+0x%x'
                      % (slot, slot * 8, fn, off))
            if len(self.getters) > 24:
                print('     ... 另有 %d 个' % (len(self.getters) - 24))
        else:
            print('\n  成员指针 getter: 0 个')
            print('     （若这是组件式布局的类，字段会藏在成员对象里，'
                  '这里看不到属正常）')

        if self.inline_getters:
            print('\n  内联成员 getter (%d 个):' % len(self.inline_getters))
            for slot, fn, off in self.inline_getters[:12]:
                print('     slot %-4d (0x%04x)  fn=0x%-9x  this+0x%x'
                      % (slot, slot * 8, fn, off))

        if self.containers:
            print('\n  容器字段 (vector.size() 形态):')
            for (off, w), c in sorted(self.containers.items(),
                                      key=lambda x: -x[1]):
                slot, fn = self.container_samples[(off, w)]
                print('     this+0x%-5x 元素宽 %2dB  x%-4d 例: slot%d fn=0x%x'
                      % (off, w, c, slot, fn))
        else:
            print('\n  容器字段: 未发现')
        print()


def _main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if len(args) < 2:
        print(__doc__)
        return
    path = args[0]
    rt = SoRuntime(path)
    rt.report()
    for a in args[1:]:
        try:
            vt = int(a, 0)
        except ValueError:
            continue
        ci = ClassInfo(rt, vt)
        ci.scan_getters().scan_containers()
        ci.report('0x%x' % vt)


if __name__ == '__main__':
    _main()
