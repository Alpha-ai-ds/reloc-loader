#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest —— 自动化验证。改完代码跑一遍，确认没弄坏东西。

    python3 selftest.py                 # 用自带的系统库测试
    python3 selftest.py <big.so>        # 额外用一个大 so 跑完整流程

测试项
------
  1. ELF 解析 + 重定位能跑通
  2. 错误输入被正确拒绝（非 ELF / 不支持的架构）
  3. base 不变性：同一个文件用不同 base 加载，虚表槽位数必须一致
     —— 这条曾经挂过（段地址没跟着 base 偏移），是最有价值的回归测试
  4. 指纹稳定性：同一个文件换个 base，同一个函数的指纹必须相同
     —— 这条也挂过（capstone 把 bl 的相对跳转解析成绝对地址，
        被当成立即数收进指纹，导致自匹配只有 57%）
  5. 大 so 上能枚举出虚表，且已知地址能被找到
"""

import glob
import os
import struct
import sys

from so_loader import SoRuntime, SoRuntimeError, EM_AARCH64, EM_X86_64

PASS, FAIL, SKIP = '  [PASS] ', '  [FAIL] ', '  [SKIP] '
_results = [0, 0, 0]


def check(cond, name, detail=''):
    if cond:
        _results[0] += 1
        print(PASS + name + (('  (%s)' % detail) if detail else ''))
    else:
        _results[1] += 1
        print(FAIL + name + (('  (%s)' % detail) if detail else ''))
    return bool(cond)


def skip(name, why):
    _results[2] += 1
    print(SKIP + name + '  (%s)' % why)


def find_syslibs():
    """找几个系统库当测试样本。优先 C++ 的（有 vtable）。"""
    cands = []
    for pat in ('/usr/lib/x86_64-linux-gnu/libstdc++.so.6',
                '/usr/lib/x86_64-linux-gnu/libc.so.6',
                '/usr/lib/x86_64-linux-gnu/libm.so.6',
                '/nix/store/*/lib/libstdc++.so.*',
                '/nix/store/*/lib/libc.so.*'):
        cands.extend(sorted(glob.glob(pat)))
    out = []
    seen = set()
    for c in cands:
        try:
            with open(c, 'rb') as f:
                if f.read(4) != b'\x7fELF':
                    continue
                f.seek(0x12)
                m = struct.unpack('<H', f.read(2))[0]
        except Exception:
            continue
        if m in (EM_AARCH64, EM_X86_64) and c not in seen:
            seen.add(c)
            out.append(c)
    return out[:4]


def t_basic(so):
    print('\n--- %s ---' % os.path.basename(so))
    rt = SoRuntime(so)
    check(len(rt.segs) > 0, 'PT_LOAD 段解析', '%d 段' % len(rt.segs))
    check(rt.stats['total'] > 0 or len(rt.patches) == 0,
          '重定位表解析', '%d 项' % rt.stats['total'])
    return rt


def t_base_invariance(so):
    """base 不变性 —— 最有价值的一条回归测试。"""
    rt0 = SoRuntime(so, base=0)
    rt1 = SoRuntime(so, base=0x40000000)
    check(len(rt0.segs) == len(rt1.segs), 'base 偏移后段数一致')

    # 段地址必须跟着 base 走
    ok = True
    for a, b in zip(rt0.segs, rt1.segs):
        if b['va'] - a['va'] != 0x40000000:
            ok = False
    check(ok, 'base 偏移后段地址同步偏移')

    # 挑一段「没有重定位补丁」的位置比较字节。
    # 注意：不能随便挑 —— 有补丁的位置本来就该随 base 变化
    # （补丁值 = base + addend），拿它比较会得到假失败。
    probe = None
    for s in rt0.segs:
        lo, hi = s['va'], s['va'] + s['fsz']
        va = lo
        while va + 64 <= hi:
            if not any(va <= p < va + 64 for p in rt0.patches):
                probe = va
                break
            va += 64
        if probe:
            break
    if probe is None:
        skip('base 偏移后字节一致', '没找到无补丁的 64 字节窗口')
        return rt0, rt1
    b0 = rt0.read(probe, 64)
    b1 = rt1.read(probe + 0x40000000, 64)
    check(b0 == b1, 'base 偏移后无补丁区域字节一致',
          '@0x%x' % probe)
    # 反过来：有补丁的位置，值必须正好差一个 base
    if rt0.patches:
        pv = next(iter(rt0.patches))
        v0 = rt0.read_ptr(pv)
        v1 = rt1.read_ptr(pv + 0x40000000)
        check(v1 - v0 == 0x40000000, 'base 偏移后补丁值正好差一个 base',
              '0x%x -> 0x%x' % (v0, v1))
    return rt0, rt1


def t_errors():
    print('\n--- 错误输入 ---')
    import tempfile
    d = tempfile.mkdtemp()
    p1 = os.path.join(d, 'notelf.bin')
    with open(p1, 'wb') as f:
        f.write(b'hello world, not an elf')
    try:
        SoRuntime(p1)
        check(False, '非 ELF 被拒绝')
    except SoRuntimeError:
        check(True, '非 ELF 被拒绝')

    # 造一个 32 位 x86 的假 ELF（不支持的架构）
    p2 = os.path.join(d, 'x86.bin')
    h = b'\x7fELF' + bytes([1, 1, 1, 0]) + b'\x00' * 8
    h += struct.pack('<HH', 2, 3)          # ET_EXEC, EM_386
    with open(p2, 'wb') as f:
        f.write(h.ljust(64, b'\x00'))
    try:
        SoRuntime(p2)
        check(False, '不支持的架构被拒绝')
    except SoRuntimeError:
        check(True, '不支持的架构被拒绝')


def t_fingerprint_stability(rt0, rt1, va):
    """指纹稳定性 —— 第二条高价值回归测试。"""
    try:
        from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN
        from vtdiff import func_fingerprint, _md_for
    except ImportError:
        skip('指纹稳定性', '需要 capstone')
        return
    md = _md_for(rt0)
    f0 = func_fingerprint(rt0, va, md)
    f1 = func_fingerprint(rt1, va + 0x40000000, md)
    if f0 is None:
        skip('指纹稳定性', '该函数反汇编为空')
        return
    check(f0 == f1, '同一函数换 base 后指纹相同',
          '0x%08x vs 0x%08x' % (f0, f1 or 0))


def t_big(so):
    print('\n--- 大 so 完整流程: %s ---' % os.path.basename(so))
    rt = SoRuntime(so)
    check(len(rt.patches) > 1000, '重定位补丁已应用',
          '%d 条' % len(rt.patches))
    try:
        from vtfind import find_vtables
    except ImportError:
        skip('虚表枚举', 'vtfind 不可用')
        return
    vts = find_vtables(rt, min_slots=20)
    check(len(vts) > 0, '能枚举出候选虚表', '%d 张' % len(vts))
    if vts:
        top = vts[0]
        check(top['slots'] >= 20, '榜首槽位数合理',
              '0x%x / %d 槽' % (top['addr'], top['slots']))
        # 自匹配：换 base 后应该能 100% 找回
        try:
            from vtdiff import diff_vtables
            rt2 = SoRuntime(so, base=0x10000000)
            res = diff_vtables(rt, rt2, [top['addr']], topk=1, nins=8)
            if res and res[0]['best']:
                rate = res[0]['best'][0]['rate']
                check(rate > 0.9, '换 base 后自匹配率 > 90%%',
                      '%.1f%%' % (rate * 100))
            else:
                skip('自匹配', '未产生候选')
        except Exception as e:
            skip('自匹配', str(e))


def _main():
    print('=' * 66)
    print('  reloc-loader 自检')
    print('=' * 66)

    t_errors()

    libs = find_syslibs()
    if not libs:
        skip('系统库测试', '没找到可用的 .so')
    for so in libs:
        try:
            rt0 = t_basic(so)
        except SoRuntimeError as e:
            skip(os.path.basename(so), str(e))
            continue
        try:
            rt0b, rt1b = t_base_invariance(so)
        except Exception as e:
            skip('base 不变性', str(e))
            continue
        # 挑一个代码段里的地址测指纹
        ex = rt0.exec_ranges
        if ex:
            t_fingerprint_stability(rt0b, rt1b, ex[0][0] + 0x1000)

    big = sys.argv[1] if len(sys.argv) > 1 else None
    if big and os.path.exists(big):
        t_big(big)
    elif big:
        skip('大 so 测试', '文件不存在')

    p, f, s = _results
    print('\n' + '=' * 66)
    print('  结果: %d 通过 / %d 失败 / %d 跳过' % (p, f, s))
    print('=' * 66)
    return 1 if f else 0


if __name__ == '__main__':
    sys.exit(_main())
