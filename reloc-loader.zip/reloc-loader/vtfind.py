#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
vtfind —— 全镜像枚举虚表。不需要预先知道任何地址。

so_loader 解决「读得到」，vtinfo 解决「读出来是什么」，
vtfind 解决「在哪儿」—— 当你手上只有一个 so，连入口都没有时，
第一件事就是把所有 vtable 找出来。

==============================================================================
怎么用
==============================================================================

    python3 vtfind.py libfoo.so                    # 列出所有虚表（>= 8 槽）
    python3 vtfind.py libfoo.so --min 40           # 只看大表（靠谱的通常是大表）
    python3 vtfind.py libfoo.so --top 30           # 只看最大的 30 张
    python3 vtfind.py libfoo.so --json out.json    # 导出，供 diff 用

程序里用：

    from so_loader import SoRuntime
    from vtfind import find_vtables
    vts = find_vtables(rt, min_slots=8)

==============================================================================
判据是什么
==============================================================================

C++ 的 vtable 在内存里长这样（-2 和 -1 是 Itanium ABI 的前缀）：

    [-2]  top_offset   (ptrdiff_t)
    [-1]  typeinfo 指针
    [ 0]  第 1 个虚函数   ┐
    [ 1]  第 2 个虚函数   │ 连续若干个，全部指向 .text
    ...                   ┘

所以判据是：**数据段里一段连续的、全部指向可执行段的 8 字节指针**。

单看这一条会扫出很多噪声（函数指针数组、跳转表、GOT 都长这样）。
所以再加几条过滤：

1. **最小长度**。真实的多态类通常有十几个以上虚函数；
   长度 3~5 的多半是别的东西。默认阈值 8，可调。

2. **前缀检查**。vtable 前面通常有 top_offset(0) + typeinfo。
   命中时向后 16 字节看是不是 `0` + 一个数据段指针。
   这条不能当硬条件（有些编译器/链接器优化会省掉），
   但可以作为**打分**依据。

3. **可重复**。同一张 vtable 会被多个地方引用；只出现一次的长序列
   更可能是数据数组。这条暂未实现，需要 xref 支持。

输出的每条记录带 `score`，越高越可信。不要盲信 top-1，
**看 top-20 然后用 vtinfo 抽查**才是正确用法。

==============================================================================
限制
==============================================================================

* 只找「连续指针序列」，找不出被拆分布局或含非虚函数槽的表。
* 无法区分 vtable 和其他函数指针数组 —— 这是静态分析的根本限制，
  只能靠长度和前缀打分来排序，不能靠它下结论。
* 对开了 `-fno-rtti` 或 LTO 的二进制，前缀检查会退化（typeinfo 被裁掉）。
"""

import argparse
import json
import sys

import numpy as np

from so_loader import SoRuntime

CHUNK = 1 << 20          # 每次扫 1MB（131072 个指针槽）


def find_vtables(rt, min_slots=8, max_slots=4096, seg_filter=None,
                 split=True, split_over=200):
    """枚举所有候选 vtable。

    :param min_slots: 最小槽位数，低于此值的连续序列丢弃
    :param max_slots: 单表最大槽位（防止把整个数据段算成一张表）
    :param seg_filter: 只扫指定的段（传 [(va_start, va_end), ...]）
    :param split: 是否对超长 run 做切分
    :param split_over: 超过多少槽才尝试切分
    :return: [{'addr','slots','end','score','has_prefix','first'}, ...]
    """
    ks, vs = rt._sorted_patch_arrays()
    results = []

    if seg_filter:
        regions = list(seg_filter)
    else:
        # 只扫可写数据段 —— vtable 不会在代码段里
        regions = [(s['va'], s['va'] + max(s['fsz'], s['msz']))
                   for s in rt.segs if not (s['flags'] & 1)]

    for va_start, va_end in regions:
        pos = va_start
        while pos < va_end:
            count = min(CHUNK // 8, (va_end - pos) // 8)
            if count <= 0:
                break
            arr = rt.read_ptr_array(pos, count)

            # 有效掩码：非零 + 对齐 + 在可执行段
            valid = np.zeros(count, dtype=bool)
            for lo, hi in rt.exec_ranges:
                valid |= (arr >= np.uint64(lo)) & (arr < np.uint64(hi))
            valid &= (arr != 0)
            valid &= ((arr & np.uint64(3)) == 0)

            # 找连续 run
            idx = np.nonzero(valid)[0]
            if idx.size:
                brk = np.nonzero(np.diff(idx) != 1)[0]
                st = np.concatenate(([0], brk + 1))
                en = np.concatenate((brk, [idx.size - 1]))
                for i in range(len(st)):
                    a = int(idx[st[i]])
                    b = int(idx[en[i]])
                    n = b - a + 1
                    if n < min_slots:
                        continue
                    if n > max_slots:
                        continue
                    addr = pos + a * 8
                    if split and n > split_over:
                        parts = split_merged(rt, addr, n, min_slots)
                        if parts:
                            results.extend(parts)
                            continue
                    results.append(_mk(rt, addr, n, int(arr[a])))
            pos += count * 8

    results.sort(key=lambda r: (-r['score'], -r['slots']))
    return results


def split_merged(rt, addr, n, min_slots=8):
    """把「多张表连成一片」的长 run 切开。

    问题：相邻的两张 vtable 之间没有空隙（都是指向 .text 的指针），
    所以扫描时会被合并成一个超长 run。
    实测里出现过 1596 槽的「表」—— 那显然不是一张表。

    判据：Itanium ABI 下每张 vtable 前面有 16 字节前缀
    （top_offset 通常是 0，然后是 typeinfo 指针）。
    所以 run 内部如果某个位置满足「前 16 字节 = 0 + 数据段指针」，
    那里很可能是一张新表的起点。

    这不是精确切分 —— 更像启发式断点。但它能把 1596 槽的怪物
    拆成若干张正常大小的表，实用价值很高。
    """
    bounds = [addr]
    # 只在合理范围内探测，避免 O(n) 读太多
    step = 8
    for off in range(0, n * 8, step):
        cand = addr + off
        if off == 0:
            continue
        try:
            w0 = rt.read_ptr(cand - 16)
            w1 = rt.read_ptr(cand - 8)
        except Exception:
            continue
        if w0 == 0 and w1 != 0 and rt.in_data(w1):
            bounds.append(cand)
    bounds.append(addr + n * 8)

    out = []
    for i in range(len(bounds) - 1):
        s, e = bounds[i], bounds[i + 1]
        cnt = (e - s) // 8
        if cnt >= min_slots:
            try:
                first = rt.read_ptr(s)
            except Exception:
                first = 0
            out.append(_mk(rt, s, cnt, int(first)))
    return out if len(out) > 1 else []


def _mk(rt, addr, n, first):
    """给一个候选打分。

    score 组成：
      基础分      = 槽位数（越长越可能是真 vtable）
      前缀加分    = +20，前面 16 字节形如 top_offset(0) + typeinfo 指针
      小表惩罚    = 少于 12 槽时按比例打折
    """
    score = float(n)
    has_prefix = False
    try:
        # vtable[-2] = top_offset, vtable[-1] = typeinfo
        w0 = rt.read_ptr(addr - 16)
        w1 = rt.read_ptr(addr - 8)
        if w0 == 0 and w1 != 0 and rt.in_data(w1):
            has_prefix = True
            score += 20
    except Exception:
        pass

    # 超长 run 大概率是「多张表连成一片」或干脆就是函数指针数组。
    # 真实 C++ 类很少超过几百个虚函数，所以超过阈值后停止线性加分，
    # 并打上标记 —— 宁可排序靠后让人去查，也别让它霸占榜首。
    suspect = n > 300
    if suspect:
        score = 300.0 + (n - 300) * 0.1
    if n < 12:
        score *= (n / 12.0)
    return dict(addr=addr, slots=n, end=addr + n * 8, first=first,
                has_prefix=has_prefix, suspect_merged=suspect,
                score=round(score, 1))


def _main():
    ap = argparse.ArgumentParser(
        description='枚举 stripped ELF 里的所有候选虚表')
    ap.add_argument('so')
    ap.add_argument('--min', type=int, default=8, help='最小槽位数 (默认 8)')
    ap.add_argument('--max', type=int, default=4096, help='最大槽位数')
    ap.add_argument('--top', type=int, default=40, help='只显示前 N 条')
    ap.add_argument('--all', action='store_true', help='显示全部')
    ap.add_argument('--json', metavar='FILE', help='导出为 JSON')
    ap.add_argument('--runtime', action='store_true',
                    help='顺便打印加载/重定位信息')
    a = ap.parse_args()

    rt = SoRuntime(a.so)
    if a.runtime:
        rt.report()

    vts = find_vtables(rt, min_slots=a.min, max_slots=a.max)
    if not vts:
        print('未找到任何候选（试试 --min 4）')
        return

    if a.json:
        with open(a.json, 'w') as f:
            json.dump({'so': a.so, 'min_slots': a.min,
                       'count': len(vts), 'vtables': vts}, f, indent=1)
        print('已导出 %d 条 -> %s' % (len(vts), a.json))

    show = vts if a.all else vts[:a.top]
    print('\n候选虚表: %d 条%s' % (len(vts), '' if a.all else '（显示前 %d）' % len(show)))
    print('%-14s %-7s %-8s %-6s %-6s %s' % ('地址', '槽位', 'score', '前缀', '疑合并', '首槽'))
    print('-' * 68)
    for r in show:
        print('0x%-12x %-7d %-8s %-6s %-6s 0x%x'
              % (r['addr'], r['slots'], r['score'],
                 '有' if r['has_prefix'] else '-',
                 '是' if r.get('suspect_merged') else '-', r['first']))
    if not a.all and len(vts) > len(show):
        print('... 另有 %d 条（用 --all 或 --top N 查看）' % (len(vts) - len(show)))
    print('\n提示: 挑 score 高的用 vtinfo.py 抽查，别只信第一条。')


if __name__ == '__main__':
    _main()
