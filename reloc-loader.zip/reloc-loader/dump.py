#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dump —— 把「加载后视图」导出成外面的工具能吃的东西。

算出偏移只是第一步，后面还得在 IDA / Ghidra / Binary Ninja 里用。
这个模块负责把结果搬过去。

==============================================================================
用法
==============================================================================

导出一块内存（比如喂给 Unicorn，或丢进十六进制编辑器）:

    python3 dump.py lib.so --region 0x1270fa98:0x1000 -o vtable.bin

生成 IDA 脚本（重命名虚表 + 建函数）:

    python3 dump.py lib.so --ida 0x1270fa98 --name Player -o player.idc

生成 Ghidra 脚本:

    python3 dump.py lib.so --ghidra 0x1270fa98 --name Player -o player.py

生成 C 骨架（把 getter thunk 反解出的字段拼成 struct）:

    python3 dump.py lib.so --cheader 0x127275c8 --name Level -o level.h

打印某个地址附近的可读指针（快速看一眼这块是什么）:

    python3 dump.py lib.so --peek 0x1270fa98 --n 16

==============================================================================
说明
==============================================================================

生成的 C 头文件只是**骨架**：字段偏移来自 getter thunk 反解，
字段名是编的（`field_0x340` 这种）。它不能编译，
用途是给你一个可编辑的起点，或者在 IDA 里当 Local Types 粘贴。
"""

import argparse
import os
import sys

from so_loader import SoRuntime
from vtinfo import ClassInfo


# ------------------------------------------------------------------ IDA
def gen_ida(rt, vt, name, out):
    slots = rt.vtable_entries(vt)
    lines = []
    lines.append('#include <idc.idc>')
    lines.append('// 由 reloc-loader / dump.py 生成')
    lines.append('// vtable @0x%x  %d 槽' % (vt, len(slots)))
    lines.append('static main() {')
    lines.append('  auto vt = 0x%x;' % vt)
    lines.append('  set_name(vt, "%s_vtable", SN_CHECK);' % name)
    lines.append('  auto i, p;')
    lines.append('  for (i = 0; i < %d; i++) {' % len(slots))
    lines.append('    p = qword(vt + i * 8);')
    lines.append('    if (p == 0) break;')
    lines.append('    set_name(p, form("%%s_vt_%%d", "%s", i), SN_CHECK);' % name)
    lines.append('    // 只在还没有函数体时才建，避免破坏已有分析')
    lines.append('    if (get_func_flags(p) == -1) {')
    lines.append('      add_func(p, BADADDR);')
    lines.append('    }')
    lines.append('  }')
    lines.append('  msg("done: %%d slots\\n", %d);' % len(slots))
    lines.append('}')
    with open(out, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    return len(slots)


# --------------------------------------------------------------- Ghidra
def gen_ghidra(rt, vt, name, out):
    slots = rt.vtable_entries(vt)
    lines = []
    lines.append('# 由 reloc-loader / dump.py 生成')
    lines.append('# vtable @0x%x  %d 槽' % (vt, len(slots)))
    lines.append('# 在 Ghidra 的 Script Manager 里跑（Jython）')
    lines.append('from ghidra.program.model.symbol import SourceType')
    lines.append('')
    lines.append('vt_addr = toAddr(0x%x)' % vt)
    lines.append('n = %d' % len(slots))
    lines.append('')
    lines.append('fm = currentProgram.getFunctionManager()')
    lines.append('st = SourceType.USER_DEFINED')
    lines.append('')
    lines.append('# 先给虚表本身命名')
    lines.append('try:')
    lines.append('    createLabel(vt_addr, "%s_vtable", True)' % name)
    lines.append('except Exception as e:')
    lines.append('    print("label vt failed:", e)')
    lines.append('')
    lines.append('for i in range(n):')
    lines.append('    a = vt_addr.add(i * 8)')
    lines.append('    try:')
    lines.append('        p = toAddr(getLong(a))')
    lines.append('    except Exception:')
    lines.append('        break')
    lines.append('    if p.getOffset() == 0:')
    lines.append('        break')
    lines.append('    nm = "%s_vt_%%d" %% i' % name)
    lines.append('    try:')
    lines.append('        createLabel(p, nm, True)')
    lines.append('    except Exception as e:')
    lines.append('        print("label", i, "failed:", e)')
    lines.append('    if fm.getFunctionAt(p) is None:')
    lines.append('        try:')
    lines.append('            createFunction(p, nm)')
    lines.append('        except Exception as e:')
    lines.append('            print("func", i, "failed:", e)')
    lines.append('')
    lines.append('print("done %d slots")' % len(slots))
    with open(out, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    return len(slots)


# ------------------------------------------------------------- C 头文件
def gen_cheader(rt, vt, name, out):
    ci = ClassInfo(rt, vt)
    ci.scan_getters().scan_containers()

    fields = {}
    for slot, fn, off in ci.getters:
        fields.setdefault(off, []).append(('ptr', slot))
    for slot, fn, off in ci.inline_getters:
        fields.setdefault(off, []).append(('inline', slot))

    lines = []
    lines.append('/* 由 reloc-loader / dump.py 生成 —— 骨架，字段名是编的 */')
    lines.append('/* vtable @0x%x  %d 槽 */' % (vt, len(ci.slots)))
    lines.append('/*')
    lines.append(' * 字段偏移来自「成员 getter thunk」反解:')
    lines.append(' *     ldr x0, [x0, #0x340]; ret    ->  该字段在 +0x340')
    lines.append(' * 类型是猜的（默认 void*），需要你按语义改。')
    lines.append(' * 未覆盖的字段不在这里 —— 这个类可能有别的访问方式。')
    lines.append(' */')
    lines.append('')
    lines.append('#pragma once')
    lines.append('')
    lines.append('typedef struct %s {' % name)
    if not fields:
        lines.append('    /* 未找到成员 getter —— 这个类可能是组件式布局，')
        lines.append('       字段藏在成员对象里，扫不到。 */')
        lines.append('    char _unknown[0x100];')
    else:
        pos = 0
        for off in sorted(fields):
            kinds = fields[off]
            if off > pos:
                lines.append('    char _pad_%x[0x%x];' % (pos, off - pos))
            kind = kinds[0][0]
            slots = ','.join('vt[%d]' % s for _k, s in kinds)
            ty = 'void*' if kind == 'ptr' else '/* inline */ char'
            comment = '  /* %s */' % slots if len(kinds) <= 3 else ''
            lines.append('    %-16s field_%x;%s' % (ty, off, comment))
            pos = off + 8
        lines.append('    char _tail[0x40];  /* 后面还有，长度未知 */')

    if ci.containers:
        lines.append('')
        lines.append('    /* ---- 容器字段（元素宽度由 lsr 反解）---- */')
        for (off, w), c in sorted(ci.containers.items(), key=lambda x: x[0][0]):
            lines.append('    /* +0x%-5x 元素 %2d 字节，出现 %d 次 */' % (off, w, c))
    lines.append('} %s;' % name)
    lines.append('')
    lines.append('/* vtable 槽位数: %d */' % len(ci.slots))
    with open(out, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    return len(fields)


# ----------------------------------------------------------------- peek
def peek(rt, va, n=16):
    print('  peek @0x%x  (%d × 8 字节)' % (va, n))
    print('  %-14s %-18s %s' % ('地址', '值', '说明'))
    print('  ' + '-' * 58)
    arr = rt.read_ptr_array(va, n)
    for i in range(n):
        p = int(arr[i])
        a = va + i * 8
        if p == 0:
            note = '(0)'
        elif rt.is_code_ptr(p):
            note = '<< 代码段'
        elif rt.in_data(p):
            note = '.data'
        else:
            note = '?'
        print('  0x%-12x 0x%-16x %s' % (a, p, note))


def _main():
    ap = argparse.ArgumentParser(description='导出加载后视图到其他工具')
    ap.add_argument('so')
    ap.add_argument('--region', help='导出区间 VA:SIZE')
    ap.add_argument('--peek', help='打印某地址附近指针，如 0x1270fa98')
    ap.add_argument('--n', type=int, default=16, help='peek 多少个')
    ap.add_argument('--ida', help='生成 IDA 脚本，给 vtable 地址')
    ap.add_argument('--ghidra', help='生成 Ghidra 脚本，给 vtable 地址')
    ap.add_argument('--cheader', help='生成 C 骨架，给 vtable 地址')
    ap.add_argument('--name', default='Class0', help='生成物里的类名')
    ap.add_argument('-o', '--out', help='输出文件')
    a = ap.parse_args()

    rt = SoRuntime(a.so)

    if a.peek:
        peek(rt, int(a.peek, 0), a.n)
        return

    if a.region:
        va_s, sz_s = a.region.split(':')
        va, sz = int(va_s, 0), int(sz_s, 0)
        out = a.out or ('dump_0x%x.bin' % va)
        with open(out, 'wb') as f:
            f.write(rt.dump_region(va, sz))
        print('  已导出 0x%x + 0x%x (%d 字节) -> %s' % (va, sz, sz, out))
        return

    if a.ida:
        out = a.out or ('%s.idc' % a.name)
        n = gen_ida(rt, int(a.ida, 0), a.name, out)
        print('  IDA 脚本 -> %s  (%d 槽)' % (out, n))
        return

    if a.ghidra:
        out = a.out or ('%s_ghidra.py' % a.name)
        n = gen_ghidra(rt, int(a.ghidra, 0), a.name, out)
        print('  Ghidra 脚本 -> %s  (%d 槽)' % (out, n))
        return

    if a.cheader:
        out = a.out or ('%s.h' % a.name)
        n = gen_cheader(rt, int(a.cheader, 0), a.name, out)
        print('  C 骨架 -> %s  (%d 个字段)' % (out, n))
        return

    ap.print_help()


if __name__ == '__main__':
    _main()
