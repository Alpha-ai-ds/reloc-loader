#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
vtdiff —— 跨版本匹配虚表，以及同版本内的继承族聚类。

地址会变，代码不会（大部分时候）。这个工具就靠这一点工作。

==============================================================================
它解决什么问题
==============================================================================

你在 v1 上做了半天逆向，得到一批 vtable 地址和方法槽位。
v2 出来了 —— 所有地址全变，之前的工作看起来作废了。

常见的做法是「重新找一遍」。但大部分代码其实没改：
同一个类的同一个方法，v1 里在 0x747559c，v2 里在 0x7512340，
字节可能一模一样，只是位置挪了。

所以正确的锚不是地址，是**函数体的形状**。

==============================================================================
指纹怎么算
==============================================================================

取函数前 N 条指令，只保留「骨架」：

    ldr  x0, [x0, #0x340]   ->  ldr + 寄存器模式
    mov  w0, #1             ->  mov + 立即数（保留立即数，它常是枚举值）

具体地：
  - 记下 mnemonic
  - 记下操作数里的**大立即数**（>= 0x100），小立即数当噪声丢掉
    （寄存器编号每次编译都可能变，但 0x340 这种字段偏移不会）
  - 忽略寄存器名

然后 FNV-1a 哈希。

这样得到的东西对「编译器重新分配了寄存器」免疫，
对「函数被挪到别处」免疫，但对「函数体真的改了」敏感 ——
正好是我们想要的。

==============================================================================
用法
==============================================================================

跨版本匹配：

    python3 vtdiff.py old.so new.so --old-vts 0x1270fa98,0x127275c8

    输出：old 的每张表在 new 里最可能是哪张，以及逐槽位的匹配率。

同版本继承族聚类：

    python3 vtdiff.py lib.so --family --min 50

    输出：按「前若干槽指纹」分组的 vtable 集群。
    同族 = 这些类共享一批虚函数实现（通常是继承关系）。

==============================================================================
限制
==============================================================================

* 匹配是**候选排序**，不是确证。务必看匹配率：
  >80% 基本可信，50~80% 需要抽查，<50% 当成没匹配上。
* 内联和 LTO 会让指纹大面积失真。
* 小函数（比如就一句 `ret`）指纹区分度极低，聚在一起很正常。
"""

import argparse
import sys

import numpy as np

from so_loader import SoRuntime
from vtfind import find_vtables

# ------------------------------------------------------------------ 指纹

# 这些指令的立即数通常无意义（纯寄存器搬运 / 栈操作）
_NOISE_MNEMONICS = {'nop', 'ret', 'mov'}


def func_fingerprint(rt, va, md, nins=10, keep_imm=True,
                     min_imm=0x20, max_imm=0x10000):
    """算一个函数的「行为指纹」。

    对寄存器重分配和地址变动免疫，对函数体改动敏感。

    关键设计：**丢弃看起来像地址的立即数**。

    capstone 会把 `bl #0x747559c` 这类相对跳转解析成绝对目标地址。
    如果把这玩意儿收进指纹，那么同一个 so 换个加载基址指纹就全变了
    —— 自匹配都只有 57%，实测踩过。

    所以规则是：
      - 小立即数（|v| < 0x20）   保留 —— 多是 `mov w0,#1` 这种枚举/标志
      - 中等（0x20 ~ 0x10000）    保留 —— 字段偏移、数组长度，是最有价值的部分
      - 落在 exec/data 段范围内   丢弃 —— 那是地址，随基址/版本变
      - 其他大数                  保留 —— 可能是魔数、哈希常量

    这样 `ldr x0,[x0,#0x340]` 的 0x340 会留下（这是我们要锚的东西），
    而 `bl #0x747559c` 的 0x747559c 会被丢掉。
    """
    try:
        code = rt.read(va, nins * 4)
    except Exception:
        return None
    if not code or code == b'\x00' * len(code):
        return None
    parts = []
    cnt = 0
    for ins in md.disasm(code, va):
        m = ins.mnemonic
        if m == 'ret':
            parts.append('ret')
            break
        parts.append(m)
        if keep_imm:
            for tok in ins.op_str.replace(',', ' ').split():
                if not tok.startswith('#'):
                    continue
                try:
                    v = int(tok[1:], 0)
                except ValueError:
                    continue
                av = abs(v)
                if av < min_imm:
                    continue                       # 太小的噪声
                if av >= max_imm and (rt.in_exec(v) or rt.in_data(v)):
                    continue                       # 这是地址，丢弃
                parts.append('i%x' % (v & 0xFFFFFFFF))
        cnt += 1
        if cnt >= nins:
            break
    if not parts:
        return None
    h = 0x811c9dc5
    for p in parts:
        for b in p.encode():
            h = ((h ^ b) * 0x01000193) & 0xFFFFFFFF
    return h


def vtable_fingerprints(rt, vt, md, nslots=None, nins=10):
    """整张表的指纹列表（每个槽位一个）。"""
    slots = rt.vtable_entries(vt, nslots or 3000)
    fps = []
    for s in slots:
        fps.append(func_fingerprint(rt, s, md, nins=nins))
    return fps


def _md_for(rt):
    from capstone import Cs
    if rt.machine == 183:          # EM_AARCH64
        from capstone import CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN
        md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
    else:
        from capstone import CS_ARCH_X86, CS_MODE_64
        md = Cs(CS_ARCH_X86, CS_MODE_64)
    md.detail = False
    return md


# -------------------------------------------------------------- 跨版本匹配
def diff_vtables(rt_old, rt_new, old_vts, topk=3, nins=10, max_slots=400):
    """把 old 的每张 vtable 匹配到 new 里的候选。

    策略（两步，先粗后细）：
      1. 粗筛：按槽位数接近度取一批候选（vtable 大小不常变）
      2. 细排：逐槽比较行为指纹，算匹配率

    :return: [{'old','slots','best':[{'addr','rate','common'}, ...]}, ...]
    """
    md_old = _md_for(rt_old)
    md_new = _md_for(rt_new)

    print('  扫描 new 的候选虚表 ...', file=sys.stderr)
    cands = find_vtables(rt_new, min_slots=8)
    print('  候选 %d 张，逐一算指纹 ...' % len(cands), file=sys.stderr)

    cand_fps = []
    for c in cands:
        if c['slots'] > max_slots and not c.get('suspect_merged'):
            pass
        cand_fps.append((c['addr'], c['slots'],
                         vtable_fingerprints(rt_new, c['addr'], md_new,
                                             nslots=c['slots'], nins=nins)))

    out = []
    for ov in old_vts:
        n = rt_old.vtable_len(ov)
        if n == 0:
            out.append(dict(old=ov, slots=0, best=[], note='old 里读不到（地址可能已失效）'))
            continue
        ofps = vtable_fingerprints(rt_old, ov, md_old, nslots=n, nins=nins)

        # 粗筛：槽位数在 ±40% 内
        pool = [(a, s, f) for a, s, f in cand_fps
                if abs(s - n) <= max(4, int(n * 0.4))]
        scored = []
        for a, s, f in pool:
            common = 0
            total = 0
            for i in range(min(n, s)):
                x = ofps[i]
                y = f[i] if i < len(f) else None
                if x is None or y is None:
                    continue
                total += 1
                if x == y:
                    common += 1
            if total == 0:
                continue
            rate = common / float(total)
            scored.append(dict(addr=a, slots=s, rate=round(rate, 3),
                               common=common, total=total))
        scored.sort(key=lambda r: (-r['rate'], -r['common']))
        out.append(dict(old=ov, slots=n, best=scored[:topk]))
    return out


# ------------------------------------------------------------ 继承族聚类
def families(rt, vts, prefix_len=8, nins=8):
    """按「前 N 槽指纹」把 vtable 分组。

    同一族 = 这些类共享前若干个虚函数的实现。
    在 Itanium ABI 下这通常意味着继承关系（子类未 override 的方法
    指向与父类相同的实现），或者干脆是同一个模板实例化出来的。

    :return: [(族指纹, [成员地址...]), ...] 按成员数降序
    """
    md = _md_for(rt)
    groups = {}
    for v in vts:
        addr = v['addr'] if isinstance(v, dict) else v
        fps = vtable_fingerprints(rt, addr, md, nslots=prefix_len, nins=nins)
        key = tuple(fps[:prefix_len])
        groups.setdefault(key, []).append(addr)
    fams = sorted(groups.items(), key=lambda kv: -len(kv[1]))
    return fams


# -------------------------------------------------------------------- CLI
def _main():
    ap = argparse.ArgumentParser(description='虚表跨版本匹配 / 继承族聚类')
    ap.add_argument('so')
    ap.add_argument('so2', nargs='?', help='第二个版本（给定时做跨版本匹配）')
    ap.add_argument('--old-vts', help='old 里的 vtable 地址，逗号分隔')
    ap.add_argument('--min', type=int, default=8)
    ap.add_argument('--family', action='store_true', help='同版本继承族聚类')
    ap.add_argument('--prefix', type=int, default=8, help='族聚类看前几槽')
    ap.add_argument('--nins', type=int, default=10, help='指纹取几条指令')
    ap.add_argument('--topk', type=int, default=3)
    ap.add_argument('--base', default='0', help='so1 的假想加载基址（测试用）')
    ap.add_argument('--base2', default='0', help='so2 的假想加载基址（测试用）')
    a = ap.parse_args()

    rt1 = SoRuntime(a.so, base=int(a.base, 0))
    if not a.so2:
        rt1.report()

    if a.so2:
        if not a.old_vts:
            print('跨版本匹配需要 --old-vts（old 里已知的 vtable 地址）')
            return
        rt2 = SoRuntime(a.so2, base=int(a.base2, 0))
        old_vts = [int(x, 0) for x in a.old_vts.split(',')]
        res = diff_vtables(rt1, rt2, old_vts, topk=a.topk, nins=a.nins)
        print('=' * 66)
        print('  跨版本匹配结果')
        print('=' * 66)
        for r in res:
            print('\n  old 0x%x  (%d 槽)' % (r['old'], r['slots']))
            if not r['best']:
                print('     未找到候选 —— %s' % r.get('note', ''))
                continue
            for b in r['best']:
                verdict = ('可信' if b['rate'] > 0.8 else
                           '需抽查' if b['rate'] > 0.5 else '不可信')
                print('     -> 0x%-12x 匹配率 %5.1f%%  (%d/%d)  [%s]'
                      % (b['addr'], b['rate'] * 100, b['common'],
                         b['total'], verdict))
        return

    if a.family or True:
        vts = find_vtables(rt1, min_slots=a.min)
        fams = families(rt1, vts, prefix_len=a.prefix, nins=a.nins)
        multi = [(k, v) for k, v in fams if len(v) > 1]
        print('=' * 66)
        print('  继承族聚类（前 %d 槽指纹相同）' % a.prefix)
        print('=' * 66)
        print('  总候选: %d 张，其中 %d 个族含多个成员' % (len(vts), len(multi)))
        for k, v in multi[:25]:
            print('\n  族 (%d 个成员)  指纹前 3 槽: %s'
                  % (len(v), [('%08x' % x) if x else '-' for x in k[:3]]))
            for m in v[:12]:
                print('      0x%x' % m)
            if len(v) > 12:
                print('      ... 另有 %d 个' % (len(v) - 12))


if __name__ == '__main__':
    _main()
