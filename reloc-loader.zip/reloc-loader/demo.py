#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
demo.py —— 端到端自检。

跑完这个脚本，你应该看到：

    1. 重定位前后的对比：同一地址，重定位前全 0，重定位后是合法函数指针
    2. 一张真实的 vtable 被读出来
    3. 从这个类的成员方法里反解出的字段偏移和容器

如果第 1 步就已经「重定位前也非零」，说明那个 so 的 vtable 是静态初始化的，
本工具对它没那么关键 —— 但对绝大多数 C++ so，你会看到明显的 0 → 有值。

用法:
    python3 demo.py <lib.so> <vtable_addr> [更多 vtable 地址...]

没参数时，若环境里存在示例 so 会自动用它。
"""

import os
import sys

from so_loader import SoRuntime
from vtinfo import ClassInfo

DEFAULT_SO = '/data/workspace/mcpe/libminecraftpe.so'
DEFAULT_VTS = [0x1270fa98, 0x127275c8]


def show_before_after(rt, va, n=8):
    """同一个地址，重定位前后各读一次。

    这是最能说明问题的演示：绕开 rt.read()，直接走文件偏移读原始字节。
    """
    print('\n  重定位前后对比 @0x%x' % va)
    raw_after = []
    for i in range(n):
        raw_after.append(rt.read_ptr(va + i * 8))
    raw_before = []
    for i in range(n):
        o = rt.v2o(va + i * 8)
        if o is None:
            raw_before.append(None)
            continue
        rt.f.seek(o)
        raw_before.append(int.from_bytes(rt.f.read(8), 'little'))
    print('     %-4s %-18s %-18s' % ('槽', '文件里（重定位前）', '加载后'))
    for i, (b, a) in enumerate(zip(raw_before, raw_after)):
        bs = ('0x%x' % b) if b else '0'
        as_ = ('0x%x' % a) if a else '0'
        mark = '  ← 被填充' if (b == 0 and a) else ''
        print('     [%-2d] %-18s %-18s%s' % (i, bs, as_, mark))


def main():
    args = sys.argv[1:]
    if args:
        path = args[0]
        vts = [int(a, 0) for a in args[1:]] if len(args) > 1 else []
    elif os.path.exists(DEFAULT_SO):
        path = DEFAULT_SO
        vts = DEFAULT_VTS
        print('  (未指定参数，使用环境内的示例 so)')
    else:
        print(__doc__)
        return

    if not vts:
        print('  需要至少一个 vtable 地址。用法: demo.py <lib.so> <vtable_addr>...')
        return

    print('=' * 66)
    print('  so_loader / vtinfo  自检')
    print('=' * 66)
    print('  目标: %s' % path)

    rt = SoRuntime(path)
    rt.report()

    print('=' * 66)
    print('  第一步：验证重定位确实生效')
    print('=' * 66)
    show_before_after(rt, vts[0])

    print('\n' + '=' * 66)
    print('  第二步：读虚表')
    print('=' * 66)
    for vt in vts:
        n = rt.vtable_len(vt)
        print('  0x%x -> %d 槽' % (vt, n))
        for i, p in enumerate(rt.vtable_entries(vt, 6)):
            print('     [%d] 0x%x' % (i, p))

    print('\n' + '=' * 66)
    print('  第三步：从成员方法反解类结构')
    print('=' * 66)
    for vt in vts:
        ci = ClassInfo(rt, vt)
        ci.scan_getters().scan_containers()
        ci.report('0x%x' % vt)

    print('=' * 66)
    print('  自检完成')
    print('=' * 66)


if __name__ == '__main__':
    main()
